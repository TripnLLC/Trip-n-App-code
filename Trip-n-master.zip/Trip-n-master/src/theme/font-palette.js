export const fontPalette = {
  SFProDisplay: {
    blackItalic: 'SFProDisplay-BlackItalic',
    bold: 'SFProDisplay-Bold',
    heavyItalic: 'SFProDisplay-HeavyItalic',
    lightItalic: 'SFProDisplay-LightItalic',
    medium: 'SFProDisplay-Medium',
    regular: 'SFProDisplay-Regular',
    semiBoldItalic: 'SFProDisplay-SemiBoldItalic',
    thinItailc: 'SFProDisplay-ThinItalic',
    ultraThinItalic: 'SFProDisplay-UltraLightItalic',
  },
};
