export const PRESET = {
  INFO: 'info',
  DISABLED: 'disabled',
  SUCCESS: 'success',
  ERROR: 'error',
  PRIMARY: 'primary',
};
