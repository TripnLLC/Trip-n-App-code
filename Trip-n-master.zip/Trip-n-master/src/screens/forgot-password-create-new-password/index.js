import React from 'react';
import { View, Text, SafeAreaView, StatusBar } from 'react-native';
import styles from './styles';

export const ForgotPasswordCreateNewPasswordScreen = () => {
  return (
    <SafeAreaView style={styles.screen}>
      <StatusBar />
    </SafeAreaView>
  );
};
