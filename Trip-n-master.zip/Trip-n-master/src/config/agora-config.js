export const AgoraConfig = {
  appId: 'a7dbe5e4d7574145b90146011fca9599',
  token: 'fa3be476a26a4a5893837112d39ac4c5',
};
