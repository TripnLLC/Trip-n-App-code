/**
 * Common action types
 */
export const ON_ERROR = 'ON_ERROR';
export const LOGOUT = 'LOGOUT';
